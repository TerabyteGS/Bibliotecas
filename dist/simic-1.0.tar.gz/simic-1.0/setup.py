from setuptools import setup

setup(
    name='simic',
    version='1.0',
    packages=['simic'],
    install_requires=[
        'selenium',
        
    ]
)
